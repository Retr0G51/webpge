# config.py
# Archivo de configuración para el Bot de Carl'Sales

# =====================
# CONFIGURACIÓN BÁSICA
# =====================

# Token del bot (obtener de @BotFather en Telegram)
BOT_TOKEN = "7927157662:AAGryPTF5KAFfmY3aSV2osd4jt2KeS-7nE4"

# ID del grupo donde recibir notificaciones de pedidos
# Para obtenerlo: agrega el bot al grupo y usa /admin_stats
GRUPO_PEDIDOS_ID = "4934822560"

# Tu ID de Telegram para comandos de administrador
# Para obtenerlo: envía /start al bot y revisa los logs
ADMIN_ID = "5979848389"

# =====================
# INFORMACIÓN DEL NEGOCIO
# =====================

NOMBRE_TIENDA = "El Cairo"
PROPIETARIO = "Bruno Bernal"
INSTAGRAM = "@bruno.b_diaz"
EMAIL = "automatix.studio@gmail.com"

# =====================
# PRODUCTOS
# =====================

PRODUCTOS = {
    "modelo1": {
        "nombre": "Camiseta Modelo 1",
        "precio": 3000,
        "descripcion": "Diseño exclusivo de Carl'Sales",
        "foto": "https://tu-servidor.com/modelo1.jpg"  # Cambia por tu URL real
    },
    "modelo2": {
        "nombre": "Camiseta Modelo 2", 
        "precio": 4500,
        "descripcion": "Diseño premium de Carl'Sales",
        "foto": "https://tu-servidor.com/modelo2.jpg"  # Cambia por tu URL real
    },
    "modelo3": {
        "nombre": "Camiseta Modelo 3",
        "precio": 6000,
        "descripcion": "Diseño de lujo de Carl'Sales",
        "foto": "https://tu-servidor.com/modelo3.jpg"  # Cambia por tu URL real
    }
}

# Tallas disponibles
TALLAS = ["M", "L", "XL"]

# =====================
# ZONAS DE ENTREGA
# =====================

ZONAS_HABANA = {
    "centro": {"nombre": "Centro Habana", "costo": 100},
    "vedado": {"nombre": "Vedado", "costo": 150},
    "miramar": {"nombre": "Miramar", "costo": 200},
    "habana_vieja": {"nombre": "Habana Vieja", "costo": 100},
    "playa": {"nombre": "Playa", "costo": 180},
    "cerro": {"nombre": "Cerro", "costo": 120},
    "otros": {"nombre": "Otras zonas", "costo": 250}
}

# =====================
# CONFIGURACIÓN TÉCNICA
# =====================

# Nombre de la base de datos
DATABASE_NAME = "carlsales_pedidos.db"

# Configuración de logging
LOG_LEVEL = "INFO"  # DEBUG, INFO, WARNING, ERROR

# Horarios de atención (para mostrar en contacto)
HORARIO_ATENCION = {
    "lunes_domingos": "8:00 AM - 12:00 AM"
}