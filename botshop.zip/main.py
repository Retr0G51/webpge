#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Bot de Telegram para Carl'Sales - Tienda de Camisetas Personalizadas
Desarrollado para Andrés R.
"""

import logging
import sqlite3
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes, ConversationHandler
import json
import os

# Configuración de logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Estados para el flujo de conversación
SELECCIONAR_MODELO, SELECCIONAR_TALLA, INGRESAR_NOMBRE, INGRESAR_DIRECCION, SELECCIONAR_ZONA, CONFIRMAR_PEDIDO = range(6)

# Configuración (EDITAR ESTOS VALORES)
BOT_TOKEN = "7927157662:AAGryPTF5KAFfmY3aSV2osd4jt2KeS-7nE4"  # Reemplazar con tu token
GRUPO_PEDIDOS_ID = "-1002552620786"  # Reemplazar con el ID de tu grupo
ADMIN_ID = "5979848389"  # Tu ID de Telegram para comandos admin

# Datos de productos
PRODUCTOS = {
    "modelo1": {
        "nombre": "Camiseta Gucci",
        "precio": 3000,
        "descripcion": "Diseño exclusivo de Carl'Sales",
        "foto": "Fotos/Modelo 1.jpg"  # URL de la foto
    },
    "modelo2": {
        "nombre": "Sudadera Gucci", 
        "precio": 4500,
        "descripcion": "Diseño premium de Carl'Sales",
        "foto": "Fotos/Modelo 2.jpg"  # URL de la foto
    },
    "modelo3": {
        "nombre": "Pullover Gucci",
        "precio": 6000,
        "descripcion": "Diseño de lujo de Carl'Sales",
        "foto": "Fotos/Modelo 3.jpg"  # URL de la foto
    }
}

TALLAS = ["M", "L", "XL"]

ZONAS_HABANA = {
    "centro": {"nombre": "Centro Habana", "costo": 100},
    "vedado": {"nombre": "Vedado", "costo": 150},
    "miramar": {"nombre": "Miramar", "costo": 200},
    "habana_vieja": {"nombre": "Habana Vieja", "costo": 100},
    "playa": {"nombre": "Playa", "costo": 180},
    "cerro": {"nombre": "Cerro", "costo": 120},
    "otros": {"nombre": "Otras zonas", "costo": 250}
}

class DatabaseManager:
    def __init__(self, db_name="carlsales_pedidos.db"):
        self.db_name = db_name
        self.init_database()
    
    def init_database(self):
        """Inicializa la base de datos"""
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS pedidos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                username TEXT,
                modelo TEXT,
                talla TEXT,
                nombre_cliente TEXT,
                direccion TEXT,
                zona TEXT,
                precio_producto INTEGER,
                costo_envio INTEGER,
                total INTEGER,
                fecha DATETIME,
                estado TEXT DEFAULT 'pendiente'
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def guardar_pedido(self, pedido_data):
        """Guarda un pedido en la base de datos"""
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO pedidos (user_id, username, modelo, talla, nombre_cliente, 
                               direccion, zona, precio_producto, costo_envio, total, fecha)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', pedido_data)
        
        pedido_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return pedido_id
    
    def obtener_pedidos(self, limit=10):
        """Obtiene los últimos pedidos"""
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT * FROM pedidos ORDER BY fecha DESC LIMIT ?
        ''', (limit,))
        
        pedidos = cursor.fetchall()
        conn.close()
        return pedidos

# Instancia del gestor de base de datos
db = DatabaseManager()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Comando /start - Mensaje de bienvenida"""
    user = update.effective_user
    
    welcome_text = f"""
🛍️ **¡Bienvenido a El Cairo!** 🛍️

Hola {user.first_name}, soy tu asistente virtual para pedidos de camisetas personalizadas.

**¿Qué puedes hacer aquí?**
• Ver nuestro catálogo de productos
• Hacer pedidos de forma rápida y sencilla
• Recibir confirmación inmediata
• Contactar con nosotros

¡Elige una opción para comenzar!
    """
    
    keyboard = [
        [InlineKeyboardButton("👕 Ver Productos", callback_data="ver_productos")],
        [InlineKeyboardButton("🛒 Hacer Pedido", callback_data="hacer_pedido")],
        [InlineKeyboardButton("📞 Contacto", callback_data="contacto")],
        [InlineKeyboardButton("ℹ️ Ayuda", callback_data="ayuda")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        welcome_text,
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )

async def productos(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Comando /productos - Muestra el catálogo"""
    await mostrar_productos(update, context)

async def mostrar_productos(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Muestra todos los productos disponibles"""
    
    # Si viene de un callback query
    if update.callback_query:
        await update.callback_query.answer()
        message = update.callback_query.message
        send_method = message.reply_text
    else:
        send_method = update.message.reply_text
    
    catalog_text = "👕 **CATÁLOGO EL CAIRO** 👕\n\n"
    
    for key, producto in PRODUCTOS.items():
        catalog_text += f"**{producto['nombre']}**\n"
        catalog_text += f"💰 Precio: {producto['precio']} CUP\n"
        catalog_text += f"📝 {producto['descripcion']}\n"
        catalog_text += f"📏 Tallas disponibles: {', '.join(TALLAS)}\n\n"
    
    catalog_text += "🚚 **Envío disponible en toda La Habana**\n"
    catalog_text += "💬 Para hacer un pedido, usa el botón 'Hacer Pedido'"
    
    keyboard = [
        [InlineKeyboardButton("🛒 Hacer Pedido", callback_data="hacer_pedido")],
        [InlineKeyboardButton("🏠 Menú Principal", callback_data="menu_principal")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await send_method(
        catalog_text,
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )

async def contacto(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Información de contacto"""
    await update.callback_query.answer()
    
    contact_text = """
📞 CONTACTO - El Cairo

👤 Propietario: Bruno Bernal
📱 Instagram: @bruno.b_diaz
📧 Email: automatix.studio@gmail.com
📍 Ubicación: La Habana, Cuba

🕒 Horario de atención:
Lunes a Domingos: 8:00 AM - 12:00 AM

💬 ¿Preguntas?
Escríbenos directamente por este chat o contacta por Instagram.
    """
    
    keyboard = [
        [InlineKeyboardButton("🏠 Menú Principal", callback_data="menu_principal")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.message.reply_text(
        contact_text,
        reply_markup=reply_markup
    )

async def ayuda(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Información de ayuda"""
    await update.callback_query.answer()
    
    help_text = """
ℹ️ **AYUDA - CÓMO USAR EL BOT**

**Comandos disponibles:**
/start - Menú principal
/productos - Ver catálogo
/pedido - Hacer un pedido
/ayuda - Esta ayuda

**¿Cómo hacer un pedido?**
1️⃣ Presiona "Hacer Pedido"
2️⃣ Selecciona el modelo que deseas
3️⃣ Elige tu talla (M, L, XL)
4️⃣ Ingresa tu nombre completo
5️⃣ Proporciona tu dirección
6️⃣ Selecciona tu zona en La Habana
7️⃣ Confirma tu pedido

**Métodos de pago:**
💵 Efectivo contra entrega
💳 Transferencia móvil
🏧 Transferencia bancaria

**Tiempo de entrega:**
📦 1 - 2  días hábiles en La Habana

¿Más preguntas? ¡Contacta con nosotros!
    """
    
    keyboard = [
        [InlineKeyboardButton("🏠 Menú Principal", callback_data="menu_principal")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.message.reply_text(
        help_text,
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )

async def iniciar_pedido(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Inicia el proceso de pedido"""
    if update.callback_query:
        await update.callback_query.answer()
        message = update.callback_query.message
        send_method = message.reply_text
    else:
        send_method = update.message.reply_text
    
    # Limpiar datos previos
    context.user_data.clear()
    
    selection_text = """
🛒 **HACER PEDIDO - PASO 1/6**

Selecciona el modelo que deseas:
    """
    
    keyboard = []
    for key, producto in PRODUCTOS.items():
        keyboard.append([InlineKeyboardButton(
            f"{producto['nombre']} - {producto['precio']} CUP",
            callback_data=f"modelo_{key}"
        )])
    
    keyboard.append([InlineKeyboardButton("❌ Cancelar", callback_data="cancelar_pedido")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await send_method(
        selection_text,
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )
    
    return SELECCIONAR_MODELO

async def seleccionar_modelo(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Maneja la selección del modelo"""
    query = update.callback_query
    await query.answer()
    
    modelo_key = query.data.replace("modelo_", "")
    
    if modelo_key in PRODUCTOS:
        context.user_data['modelo'] = modelo_key
        producto = PRODUCTOS[modelo_key]
        
        # Mostrar imagen del producto si está disponible
        try:
            await query.message.reply_photo(
                photo=producto['foto'],
                caption=f"**{producto['nombre']}**\n💰 {producto['precio']} CUP\n📝 {producto['descripcion']}"
            )
        except:
            # Si falla la imagen, continuar sin ella
            pass
        
        talla_text = f"""
🛒 **HACER PEDIDO - PASO 2/6**

✅ Modelo seleccionado: **{producto['nombre']}**
💰 Precio: **{producto['precio']} CUP**

Ahora selecciona tu talla:
        """
        
        keyboard = []
        for talla in TALLAS:
            keyboard.append([InlineKeyboardButton(f"Talla {talla}", callback_data=f"talla_{talla}")])
        
        keyboard.append([InlineKeyboardButton("⬅️ Cambiar Modelo", callback_data="hacer_pedido")])
        keyboard.append([InlineKeyboardButton("❌ Cancelar", callback_data="cancelar_pedido")])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.message.reply_text(
            talla_text,
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        
        return SELECCIONAR_TALLA
    
    return SELECCIONAR_MODELO

async def seleccionar_talla(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Maneja la selección de talla"""
    query = update.callback_query
    await query.answer()
    
    talla = query.data.replace("talla_", "")
    context.user_data['talla'] = talla
    
    nombre_text = f"""
🛒 **HACER PEDIDO - PASO 3/6**

✅ Modelo: **{PRODUCTOS[context.user_data['modelo']]['nombre']}**
✅ Talla: **{talla}**

Ahora escribe tu **nombre completo**:
    """
    
    keyboard = [
        [InlineKeyboardButton("⬅️ Cambiar Talla", callback_data=f"modelo_{context.user_data['modelo']}")],
        [InlineKeyboardButton("❌ Cancelar", callback_data="cancelar_pedido")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.message.reply_text(
        nombre_text,
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )
    
    return INGRESAR_NOMBRE

async def ingresar_nombre(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Maneja el ingreso del nombre"""
    nombre = update.message.text.strip()
    
    if len(nombre) < 2:
        await update.message.reply_text(
            "❌ Por favor, ingresa tu nombre completo (mínimo 2 caracteres)."
        )
        return INGRESAR_NOMBRE
    
    context.user_data['nombre'] = nombre
    
    direccion_text = f"""
🛒 **HACER PEDIDO - PASO 4/6**

✅ Modelo: **{PRODUCTOS[context.user_data['modelo']]['nombre']}**
✅ Talla: **{context.user_data['talla']}**
✅ Nombre: **{nombre}**

Ahora escribe tu **dirección completa**:
(Incluye calle, número, entre calles, reparto/municipio)
    """
    
    keyboard = [
        [InlineKeyboardButton("❌ Cancelar", callback_data="cancelar_pedido")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        direccion_text,
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )
    
    return INGRESAR_DIRECCION

async def ingresar_direccion(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Maneja el ingreso de la dirección"""
    direccion = update.message.text.strip()
    
    if len(direccion) < 10:
        await update.message.reply_text(
            "❌ Por favor, proporciona una dirección más completa (mínimo 10 caracteres)."
        )
        return INGRESAR_DIRECCION
    
    context.user_data['direccion'] = direccion
    
    zona_text = f"""
🛒 **HACER PEDIDO - PASO 5/6**

✅ Modelo: **{PRODUCTOS[context.user_data['modelo']]['nombre']}**
✅ Talla: **{context.user_data['talla']}**
✅ Nombre: **{context.user_data['nombre']}**
✅ Dirección: **{direccion}**

Selecciona tu zona en La Habana para calcular el envío:
    """
    
    keyboard = []
    for key, zona in ZONAS_HABANA.items():
        keyboard.append([InlineKeyboardButton(
            f"{zona['nombre']} - {zona['costo']} CUP",
            callback_data=f"zona_{key}"
        )])
    
    keyboard.append([InlineKeyboardButton("❌ Cancelar", callback_data="cancelar_pedido")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        zona_text,
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )
    
    return SELECCIONAR_ZONA

async def seleccionar_zona(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Maneja la selección de zona"""
    query = update.callback_query
    await query.answer()
    
    zona_key = query.data.replace("zona_", "")
    context.user_data['zona'] = zona_key
    
    # Calcular totales
    producto = PRODUCTOS[context.user_data['modelo']]
    zona = ZONAS_HABANA[zona_key]
    precio_producto = producto['precio']
    costo_envio = zona['costo']
    total = precio_producto + costo_envio
    
    confirmacion_text = f"""
🛒 **CONFIRMAR PEDIDO - PASO 6/6**

**RESUMEN DE TU PEDIDO:**

👕 **Producto:** {producto['nombre']}
📏 **Talla:** {context.user_data['talla']}
👤 **Nombre:** {context.user_data['nombre']}
📍 **Dirección:** {context.user_data['direccion']}
🚚 **Zona:** {zona['nombre']}

**💰 PRECIOS:**
• Producto: {precio_producto} CUP
• Envío: {costo_envio} CUP
• **TOTAL: {total} CUP**

¿Confirmas tu pedido?
    """
    
    keyboard = [
        [InlineKeyboardButton("✅ Confirmar Pedido", callback_data="confirmar_si")],
        [InlineKeyboardButton("✏️ Modificar", callback_data="hacer_pedido")],
        [InlineKeyboardButton("❌ Cancelar", callback_data="cancelar_pedido")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.message.reply_text(
        confirmacion_text,
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )
    
    return CONFIRMAR_PEDIDO

async def confirmar_pedido(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Confirma el pedido final"""
    query = update.callback_query
    await query.answer()
    
    if query.data != "confirmar_si":
        return ConversationHandler.END
    
    # Preparar datos del pedido
    user = update.effective_user
    producto = PRODUCTOS[context.user_data['modelo']]
    zona = ZONAS_HABANA[context.user_data['zona']]
    
    precio_producto = producto['precio']
    costo_envio = zona['costo']
    total = precio_producto + costo_envio
    
    # Guardar en base de datos
    pedido_data = (
        user.id,
        user.username or "Sin username",
        context.user_data['modelo'],
        context.user_data['talla'],
        context.user_data['nombre'],
        context.user_data['direccion'],
        context.user_data['zona'],
        precio_producto,
        costo_envio,
        total,
        datetime.now()
    )
    
    pedido_id = db.guardar_pedido(pedido_data)
    
    # Mensaje de confirmación para el cliente
    confirmacion_cliente = f"""
✅ **¡PEDIDO CONFIRMADO!**

📄 **Número de pedido:** #{pedido_id}
👕 **Producto:** {producto['nombre']}
📏 **Talla:** {context.user_data['talla']}
👤 **Cliente:** {context.user_data['nombre']}
📍 **Dirección:** {context.user_data['direccion']}
🚚 **Zona:** {zona['nombre']}
💰 **Total:** {total} CUP

**📦 Tiempo de entrega:** 2-3 días hábiles
**💳 Pago:** Contra entrega o transferencia

¡Gracias por tu compra en Carl'Sales!
Nos contactaremos contigo pronto.
    """
    
    keyboard = [
        [InlineKeyboardButton("🏠 Menú Principal", callback_data="menu_principal")],
        [InlineKeyboardButton("🛒 Nuevo Pedido", callback_data="hacer_pedido")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.message.reply_text(
        confirmacion_cliente,
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )
    
    # Notificar al grupo de pedidos
    try:
        notificacion_admin = f"""
🚨 **NUEVO PEDIDO - CARL'SALES**

📄 **ID:** #{pedido_id}
👤 **Cliente:** {context.user_data['nombre']} (@{user.username or 'Sin username'})
📞 **Telegram ID:** {user.id}

**PRODUCTO:**
👕 {producto['nombre']}
📏 Talla: {context.user_data['talla']}

**ENTREGA:**
📍 {context.user_data['direccion']}
🚚 Zona: {zona['nombre']}

**PRECIOS:**
• Producto: {precio_producto} CUP
• Envío: {costo_envio} CUP
• **TOTAL: {total} CUP**

⏰ {datetime.now().strftime('%d/%m/%Y %H:%M')}
        """
        
        await context.bot.send_message(
            chat_id=GRUPO_PEDIDOS_ID,
            text=notificacion_admin,
            parse_mode='Markdown'
        )
    except Exception as e:
        logger.error(f"Error enviando notificación al grupo: {e}")
    
    # Limpiar datos del usuario
    context.user_data.clear()
    
    return ConversationHandler.END

async def cancelar_pedido(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Cancela el pedido actual"""
    query = update.callback_query
    await query.answer()
    
    context.user_data.clear()
    
    await query.message.reply_text(
        "❌ Pedido cancelado.\n\n¿Qué deseas hacer ahora?",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🏠 Menú Principal", callback_data="menu_principal")],
            [InlineKeyboardButton("🛒 Nuevo Pedido", callback_data="hacer_pedido")]
        ])
    )
    
    return ConversationHandler.END

async def menu_principal(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Regresa al menú principal"""
    query = update.callback_query
    await query.answer()
    
    welcome_text = f"""
🛍️ **¡Bienvenido a Carl'Sales!** 🛍️

Tu asistente virtual para camisetas personalizadas.

**¿Qué puedes hacer aquí?**
• Ver nuestro catálogo de productos
• Hacer pedidos de forma rápida y sencilla
• Recibir confirmación inmediata
• Contactar con nosotros

¡Elige una opción para comenzar!
    """
    
    keyboard = [
        [InlineKeyboardButton("👕 Ver Productos", callback_data="ver_productos")],
        [InlineKeyboardButton("🛒 Hacer Pedido", callback_data="hacer_pedido")],
        [InlineKeyboardButton("📞 Contacto", callback_data="contacto")],
        [InlineKeyboardButton("ℹ️ Ayuda", callback_data="ayuda")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.message.reply_text(
        welcome_text,
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )

# Comandos de administrador
async def admin_pedidos(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Comando para ver pedidos recientes (solo admin)"""
    if str(update.effective_user.id) != ADMIN_ID:
        await update.message.reply_text("❌ No tienes permisos para este comando.")
        return
    
    pedidos = db.obtener_pedidos(10)
    
    if not pedidos:
        await update.message.reply_text("No hay pedidos registrados.")
        return
    
    texto_pedidos = "📊 **ÚLTIMOS 10 PEDIDOS**\n\n"
    
    for pedido in pedidos:
        fecha = datetime.strptime(pedido[11], '%Y-%m-%d %H:%M:%S.%f')
        texto_pedidos += f"**#{pedido[0]}** - {pedido[5]} - {pedido[9]} CUP\n"
        texto_pedidos += f"📅 {fecha.strftime('%d/%m/%Y %H:%M')}\n\n"
    
    await update.message.reply_text(texto_pedidos, parse_mode='Markdown')

async def admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Estadísticas básicas (solo admin)"""
    if str(update.effective_user.id) != ADMIN_ID:
        await update.message.reply_text("❌ No tienes permisos para este comando.")
        return
    
    conn = sqlite3.connect(db.db_name)
    cursor = conn.cursor()
    
    # Total de pedidos
    cursor.execute("SELECT COUNT(*) FROM pedidos")
    total_pedidos = cursor.fetchone()[0]
    
    # Total de ventas
    cursor.execute("SELECT SUM(total) FROM pedidos")
    total_ventas = cursor.fetchone()[0] or 0
    
    # Modelo más vendido
    cursor.execute("SELECT modelo, COUNT(*) as cantidad FROM pedidos GROUP BY modelo ORDER BY cantidad DESC LIMIT 1")
    modelo_popular = cursor.fetchone()
    
    conn.close()
    
    stats_text = f"""
📊 **ESTADÍSTICAS CARL'SALES**

📦 **Total pedidos:** {total_pedidos}
💰 **Total ventas:** {total_ventas} CUP
👕 **Modelo más vendido:** {PRODUCTOS[modelo_popular[0]]['nombre'] if modelo_popular else 'N/A'} ({modelo_popular[1] if modelo_popular else 0} unidades)

📅 **Última actualización:** {datetime.now().strftime('%d/%m/%Y %H:%M')}
    """
    
    await update.message.reply_text(stats_text, parse_mode='Markdown')

def main() -> None:
    """Función principal"""
    # Crear la aplicación
    application = Application.builder().token(BOT_TOKEN).build()
    
    # Handler para el flujo de pedidos
    conv_handler = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(iniciar_pedido, pattern="^hacer_pedido$"),
            CommandHandler("pedido", iniciar_pedido)
        ],
        states={
            SELECCIONAR_MODELO: [CallbackQueryHandler(seleccionar_modelo, pattern="^modelo_")],
            SELECCIONAR_TALLA: [CallbackQueryHandler(seleccionar_talla, pattern="^talla_")],
            INGRESAR_NOMBRE: [MessageHandler(filters.TEXT & ~filters.COMMAND, ingresar_nombre)],
            INGRESAR_DIRECCION: [MessageHandler(filters.TEXT & ~filters.COMMAND, ingresar_direccion)],
            SELECCIONAR_ZONA: [CallbackQueryHandler(seleccionar_zona, pattern="^zona_")],
            CONFIRMAR_PEDIDO: [CallbackQueryHandler(confirmar_pedido, pattern="^confirmar_")]
        },
        fallbacks=[
            CallbackQueryHandler(cancelar_pedido, pattern="^cancelar_pedido$"),
            CommandHandler("start", start)
        ]
    )
   # Agregar handlers  <-- Aquí empieza tu código
    application.add_handler(conv_handler)
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("productos", productos))
    application.add_handler(CommandHandler("ayuda", ayuda))
    application.add_handler(CommandHandler("admin_pedidos", admin_pedidos))
    application.add_handler(CommandHandler("admin_stats", admin_stats))
    
    # Callback query handlers
    application.add_handler(CallbackQueryHandler(mostrar_productos, pattern="^ver_productos$"))
    application.add_handler(CallbackQueryHandler(contacto, pattern="^contacto$"))
    application.add_handler(CallbackQueryHandler(ayuda, pattern="^ayuda$"))
    application.add_handler(CallbackQueryHandler(menu_principal, pattern="^menu_principal$"))
    
    # Iniciar el bot
    print("🤖 Bot Carl'Sales iniciando...")
    print("✅ Presiona Ctrl+C para detener")
    
    application.run_polling()

if __name__ == '__main__':
    main()
